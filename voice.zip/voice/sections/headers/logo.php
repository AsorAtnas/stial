<div class="vce-res-nav">
	<a class="vce-responsive-nav" href="#sidr-main"><i class="fa fa-bars"></i></a>
</div>
<div class="site-branding">
	<?php echo vce_get_branding(); ?>
</div>